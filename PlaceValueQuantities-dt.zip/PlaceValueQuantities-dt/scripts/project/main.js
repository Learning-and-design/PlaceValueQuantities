var jsonStr;
var jsonObj;
// let message = {"data": {"GameName":"Place VAlue Quantities","GameID":"GL_PVQ","ChildID":"CHILD_01","AttemptID":"ATPT_01","RewardPoints":0,"isMusic":1,"Level0":{"Completed":0,"StartTime":"Wed May 05 2021 10:04:59 GMT+0530 (India Standard Time)","EndTime":"","PlayCount":0},"Level1":{"PresentationDone":0,"Completed":0,"PlayCount":0,"CurrentPlay":0,"CorrectAttempts":0,"IncorrectAttempts":0},"Level2":{"PresentationDone":0,"Completed":0,"PlayCount":0,"CurrentPlay":0,"CorrectAttempts":0,"IncorrectAttempts":0},"Level3":{"PresentationDone":0,"Completed":0,"PlayCount":0,"CurrentPlay":0,"CorrectAttempts":0,"IncorrectAttempts":0},"Level4":{"PresentationDone":0,"Completed":0,"PlayCount":0,"CurrentPlay":0,"CorrectAttempts":0,"IncorrectAttempts":0}}};

//Replace this event with below listener while integrating with app.
// window.onload = function(e){
// 	console.log("onload");
// 	handleEvent(message);
// }
//app will trigger this event on load finish.
document.addEventListener("message", handleEvent);
function handleEvent(message) {	
	jsonObj =  message.data;
	jsonStr = JSON.stringify(message.data);
	console.log(jsonStr);
	alert("data from app"+ jsonStr);
}
runOnStartup(async runtime =>
{
	console.log("json string at start of game::",jsonStr); 
	if(jsonStr){
		const jObj = JSON.parse(jsonStr);
		runtime.globalVars.GameID = jObj.GameID;
		runtime.globalVars.ChildID = jObj.ChildID;
		runtime.globalVars.GameName = jObj.GameName;
		runtime.globalVars.AttemptID = jObj.AttemptID;

		runtime.globalVars.RewardPoints = jObj.RewardPoints;
		//Presenation level
		runtime.globalVars.PresentationDone = jObj.Level0.Completed;	
		runtime.globalVars.L0_START_TIME = jObj.Level0.StartTime;
		runtime.globalVars.L0_END_TIME = jObj.Level0.EndTime;
		runtime.globalVars.L0_PLAY_COUNT = jObj.Level0.PlayCount;
		runtime.globalVars.isMusic = jObj.isMusic;

		//set level 1 global vars
		runtime.globalVars.L1TutorialDone = jObj.Level1.PresentationDone;
		runtime.globalVars.L1_TotalTrial = jObj.Level1.PlayCount;
		runtime.globalVars.L1_trial = jObj.Level1.CurrentPlay;
		runtime.globalVars.L1_Completed = jObj.Level1.Completed;
		runtime.globalVars.L1_correctAttempts = jObj.Level1.CorrectAttempts;
		runtime.globalVars.L1_IncorrectAttempts = jObj.Level1.IncorrectAttempts;
	
		//set level 2 global vars
		runtime.globalVars.L2TutorialDone = jObj.Level2.PresentationDone;
		runtime.globalVars.L2_TotalTrial = jObj.Level2.PlayCount;
		runtime.globalVars.L2_trial = jObj.Level2.CurrentPlay;
		runtime.globalVars.L2_Completed = jObj.Level2.Completed;
		runtime.globalVars.L2_correctAttempts = jObj.Level2.CorrectAttempts;
		runtime.globalVars.L2_IncorrectAttempts = jObj.Level2.IncorrectAttempts;
	
		//set level 3 global vars
		runtime.globalVars.L3TutorialDone = jObj.Level3.PresentationDone;
		runtime.globalVars.L3_TotalTrial = jObj.Level3.PlayCount;
		runtime.globalVars.L3_trial = jObj.Level3.CurrentPlay;
		runtime.globalVars.L3_Completed = jObj.Level3.Completed;
		runtime.globalVars.L3_correctAttempts = jObj.Level3.CorrectAttempts;
		runtime.globalVars.L3_IncorrectAttempts = jObj.Level3.IncorrectAttempts;
	
		//set level 4 global vars
		runtime.globalVars.L4TutorialDone = jObj.Level4.PresentationDone;
		runtime.globalVars.L4_TotalTrial = jObj.Level4.PlayCount;
		runtime.globalVars.L4_trial = jObj.Level4.CurrentPlay;
		runtime.globalVars.L4_Completed = jObj.Level4.Completed;
		runtime.globalVars.L4_correctAttempts = jObj.Level4.CorrectAttempts;
		runtime.globalVars.L4_IncorrectAttempts = jObj.Level4.IncorrectAttempts;
		


		   
	}
	runtime.addEventListener("beforeprojectstart", () => OnBeforeProjectStart(runtime));
	
});

async function OnBeforeProjectStart(runtime)
{
	// Code to run just before 'On start of layout' on
	// the first layout. Loading has finished and initial
	// instances are created and available to use here.
	// console.log("OnBeforeProjectStart", window.location);
	runtime.addEventListener("tick", () => Tick(runtime));
}

function Tick(runtime)
{
	// Code to run every tick
}
