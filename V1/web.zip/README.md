# Consonant Phonograms
 A Plave vlaue quantities game
 This game is developed by Kartik for KEPL
# Game Link
[Play Game](https://learning-and-design.github.io/PlaceValueQuantities/)
